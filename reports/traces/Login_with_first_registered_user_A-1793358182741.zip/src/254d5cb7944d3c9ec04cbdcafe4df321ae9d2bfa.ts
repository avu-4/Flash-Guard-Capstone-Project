
import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { FlashWorld } from '../../../src/support/world';
import { config } from '../../../src/support/config';

Given(
  'I am on the Flash-Guard login page',
  async function (this: FlashWorld) {
    await this.loginPage.goto();
  }
);

// Reusable login step for User A and User B
When(
  'I log in with a valid account {string}',
  async function (this: FlashWorld, user: string) {
    let email: string;
    let password: string;

    if (user === 'USER A') {
      email = config.credentials.primary.email;
      password = config.credentials.primary.password;
    } else if (user === 'USER B') {
      email = config.credentials.secondary.email;
      password = config.credentials.secondary.password;
    } else {
      throw new Error(`Unknown test account: ${user}`);
    }

    await this.loginPage.login(email, password);
  }
);

Then(
  'I should be authenticated successfully',
  async function (this: FlashWorld) {
    await expect(this.page).toHaveURL(/\/dashboard(?:[?#].*)?$/);
  }
);

Then(
  'I should see the portfolio dashboard',
  async function (this: FlashWorld) {
    await expect(
      this.page.getByRole('heading', {
        name: 'Portfolio Overview',
      })
    ).toBeVisible();
  }
);

When(
  'I submit a registered email with an incorrect password',
  async function (this: FlashWorld) {
    await this.loginPage.login(
      config.credentials.primary.email,
      'DeliberatelyIncorrect-Test-Password!'
    );
  }
);

When(
  'I submit an unregistered email and password',
  async function (this: FlashWorld) {
    await this.loginPage.login(
      'unregistered-test-user@example.invalid',
      'Invalid-Test-Password!'
    );
  }
);

Then(
  'authentication should be rejected',
  async function (this: FlashWorld) {
    await expect(
      this.page.getByText('Invalid credentials').first()
    ).toBeVisible();
  }
);

Then(
  'I should remain outside the protected dashboard',
  async function (this: FlashWorld) {
    await expect(this.page).not.toHaveURL(
      /\/dashboard(?:[?#].*)?$/
    );
  }
);


import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { FlashWorld } from '../../../src/support/world';
import { config } from '../../../src/support/config';

Given(
  'I am on the Flash-Guard login page',
  async function (this: FlashWorld) {
    await this.loginPage.goto();
  }
);

// Reusable login step for User A and User B
When(
  'I log in with a valid account {string}',
  async function (this: FlashWorld, user: string) {
    let email: string;
    let password: string;

    
const account = user.trim().toUpperCase();

    if (account === 'USER A' || account === 'PRIMARY') {
      email = config.credentials.primary.email;
      password = config.credentials.primary.password;
    } else if (account === 'USER B' || account === 'SECONDARY') {
      email = config.credentials.secondary.email;
      password = config.credentials.secondary.password;
    } else {
      throw new Error(`Unknown test account: ${user}`);
    } 

    await this.loginPage.login(email, password);
  }
);

Then(
  'I should be authenticated successfully',
  async function (this: FlashWorld) {
    await expect(this.page).toHaveURL('/dashboard');
  }
);

Then(
  'I should see the portfolio dashboard',
  async function (this: FlashWorld) {
    await expect(
      this.page.getByRole('heading', {
        name: 'Portfolio Overview',
      })
    ).toBeVisible();
  }
);

When(
  'I submit a registered email with an incorrect password',
  async function (this: FlashWorld) {
    await this.loginPage.login(
      config.credentials.primary.email,
      'DeliberatelyIncorrect-Test-Password!'
    );
  }
);

When(
  'I submit an unregistered email and password',
  async function (this: FlashWorld) {
    await this.loginPage.login(
      'unregistered-test-user@example.invalid',
      'Invalid-Test-Password!'
    );
  }
);

Then(
  'authentication should be rejected',
  async function (this: FlashWorld) {
    await expect(
      this.page.getByText('Invalid credentials').first()
    ).toBeVisible();
  }
);

Then(
  'I should remain outside the protected dashboard',
  async function (this: FlashWorld) {
    await expect(this.page).not.toHaveURL(
      '/dashboard'
    );
  }
);

// REUSABLE STEP: Authenticate with a valid account

Given(
  'I am authenticated with a valid account',
  async function (this: FlashWorld) {
    await this.loginPage.goto();

    await this.loginPage.login(
      config.credentials.primary.email,
      config.credentials.primary.password
    );

    await expect(this.page).toHaveURL('/dashboard');
  }
);


// AUTH-005: Simulate an expired session

Given(
  'my session has expired',
  async function (this: FlashWorld) {
    await this.context.clearCookies();

    await this.page.evaluate(() => {
      localStorage.clear();
      sessionStorage.clear();
    });
  }
);

// AUTH-005: Navigate to protected dashboard

When(
  'I navigate to the protected dashboard',
  async function (this: FlashWorld) {
    await this.page.goto('/dashboard');
  }
);


// REUSABLE STEP: Verify redirection to login page

Then(
  'I should be redirected to the login page',
  async function (this: FlashWorld) {
    await expect(this.page).toHaveURL('/login');

    await expect(
      this.page.getByRole('textbox', {
        name: 'Email address'
      })
    ).toBeVisible();
  }
);


// AUTH-005: Verify protected account information is hidden

Then(
  'I should not see protected account information',
  async function (this: FlashWorld) {
    await expect(
      this.page.getByRole('heading', {
        name: 'Portfolio Overview'
      })
    ).not.toBeVisible();
  }
);


// AUTH-006: Log out of Flash-Guard

When(
  'I log out',
  async function (this: FlashWorld) {
    await this.page
      .getByRole('link', {
        name: 'logout Sign Out'
      })
      .click();
  }
);


// AUTH-006: Verify dashboard cannot be accessed after logout

Then(
  'I should not be able to access the protected dashboard',
  async function (this: FlashWorld) {
    await this.page.goto('/dashboard');

    await expect(this.page).toHaveURL('/login');

    await expect(
      this.page.getByRole('heading', {
        name: 'Portfolio Overview'
      })
    ).not.toBeVisible();
  }
);
